package tesauro;

import java.io.FileReader;
import java.io.PushbackReader;
import tesauro.lexer.*;
import tesauro.parser.*;
import tesauro.node.*;

public class Main {
	
	public static void main(String[] args) {
		try {
			
			// Arquivo de teste da linguagem Tesauro
			String arquivo = "D:\\Ufs\\Java\\tesauro\\src\\expressao2.calc";
			
      Lexer lexer = 
          new Lexer(
          new PushbackReader(
          new FileReader(arquivo), 1024)); 
     
     
      Token token;  
    
      while(!((token = lexer.next()) instanceof EOF)) {
        System.out.print(token.getClass());
        System.out.println(" ( "+token.toString()+")");
      }
			
			Parser parser = 
			    new Parser(
			    new Lexer(
          new PushbackReader(
          new FileReader(arquivo), 1024))); 

		  Start tree = parser.parse();
		 
		  tree.apply(new ASTDisplay());
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}